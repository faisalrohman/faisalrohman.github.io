/*
 * --- INSTRUKSI DEPLOY (PENTING!) ---
 * 1. Buka script.google.com
 * 2. Salin SEMUA kode di file ini dan tempel ke editor.
 * 3. Klik "Deploy" (tombol biru di kanan atas) -> "Kelola deployment".
 * 4. Klik ikon pensil (Edit) pada deployment Anda.
 * 5. PENTING: "Siapa yang memiliki akses" HARUS "Siapa saja".
 * 6. PENTING: Di "Versi", pilih "Versi baru".
 * 7. Klik "Deploy".
 * 8. Salin "URL Aplikasi Web" (/exec) dan tempel ke file index.html.
 */

// Konstanta Game
const ROPE_PULL_AMOUNT = 10;
const WIN_THRESHOLD_P1_LOSES = 5;
const WIN_THRESHOLD_P2_LOSES = 95;
const CACHE_EXPIRATION_SECONDS = 3600; // 1 jam

// --- Fungsi Utama ---
function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const action = payload.action;
    let response;

    switch (action) {
      case 'create':
        // PERUBAHAN: Menerima timer
        response = createRoom(payload.gameMode, payload.nickname, payload.timer);
        break;
      case 'join':
        response = joinRoom(payload.roomCode, payload.nickname);
        break;
      case 'getState':
        response = getState(payload.roomCode);
        break;
      case 'submitAnswer':
        response = submitAnswer(payload.roomCode, payload.player, payload.answer, payload.answerType);
        break;
      // BARU: Aksi untuk mengakhiri game karena waktu
      case 'endGameByTime':
        response = endGameByTime(payload.roomCode, payload.winner);
        break;
      default:
        response = { status: 'error', message: 'Unknown action' };
    }

    return ContentService
      .createTextOutput(JSON.stringify(response))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ status: 'error', message: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// --- Fungsi Helper Backend ---

function sanitizeName(name) {
  if (!name || name.trim() === "") return "Tamu";
  return name.trim().substring(0, 12); // Maks 12 karakter
}

/**
 * Membuat room baru
 * PERUBAHAN: Menerima gameMode, nickname, dan timer
 */
function createRoom(gameMode, nickname, timer) {
  const cache = CacheService.getScriptCache();
  let roomCode;
  let roomExists = true;
  const safeName = sanitizeName(nickname);

  const validModes = [
    '+', '-', 'x', '÷', 'campuran', 
    'kpk', 'fpb', 'gradien-persamaan', 'gradien-titik',
    'konversi-satuan', 'pola-aritmatika', 'deret-aritmatika'
  ];
  if (!validModes.includes(gameMode)) {
    gameMode = 'campuran'; // Default jika tidak valid
  }
  
  // Validasi Timer
  const validTimers = [60, 120, 300, 0]; // 1, 2, 5 menit, atau 0 (tanpa batas)
  const gameDuration = validTimers.includes(parseInt(timer, 10)) ? parseInt(timer, 10) : 0;

  while (roomExists) {
    roomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    if (!cache.get(roomCode)) roomExists = false;
  }

  const difficultyParams = getDifficultyParams(gameMode);

  const gameState = {
    roomCode: roomCode,
    gameMode: gameMode,
    timerDuration: gameDuration, // Simpan durasi timer
    gameStartTime: 0, // Akan di-set saat P2 bergabung
    player1: { id: "p1", score: 0, name: safeName },
    player2: null,
    ropePercent: 50,
    problems: { p1: null, p2: null },
    winner: null,
    gameStarted: false,
    difficulty: difficultyParams
  };

  cache.put(roomCode, JSON.stringify(gameState), CACHE_EXPIRATION_SECONDS);
  return { status: 'created', roomCode: roomCode, player: 'p1' };
}

function joinRoom(roomCode, nickname) {
  const cache = CacheService.getScriptCache();
  const roomData = cache.get(roomCode);
  const safeName = sanitizeName(nickname);

  if (!roomData) return { status: 'error', message: 'Room not found' };
  let gameState = JSON.parse(roomData);
  if (gameState.player2) return { status: 'error', message: 'Room is full' };

  gameState.player2 = { id: "p2", score: 0, name: safeName };
  
  const params = gameState.difficulty;
  
  gameState.problems.p1 = generateProblemFromParams(params);
  gameState.problems.p2 = generateProblemFromParams(params);
  gameState.gameStarted = true;
  gameState.gameStartTime = Date.now(); // BARU: Set waktu mulai game

  cache.put(roomCode, JSON.stringify(gameState), CACHE_EXPIRATION_SECONDS);
  return { status: 'joined', player: 'p2', initialState: gameState };
}

function getState(roomCode) {
  const cache = CacheService.getScriptCache();
  const roomData = cache.get(roomCode);
  if (!roomData) return { status: 'error', message: 'Room not found' };
  
  let gameState = JSON.parse(roomData);

  // BARU: Cek timer di server
  if (gameState.gameStarted && !gameState.winner && gameState.timerDuration > 0) {
    const elapsedTime = (Date.now() - gameState.gameStartTime) / 1000;
    if (elapsedTime >= gameState.timerDuration) {
      // Waktu habis! Tentukan pemenang
      if (gameState.ropePercent > 50) gameState.winner = 'p1';
      else if (gameState.ropePercent < 50) gameState.winner = 'p2';
      else gameState.winner = 'draw';
      
      cache.put(roomCode, JSON.stringify(gameState), CACHE_EXPIRATION_SECONDS);
    }
  }

  return { status: 'polled', gameState: gameState };
}

function submitAnswer(roomCode, player, answer, answerType) {
  const cache = CacheService.getScriptCache();
  const roomData = cache.get(roomCode);
  if (!roomData) return { status: 'error', message: 'Room not found' };

  let gameState = JSON.parse(roomData);
  // Cek jika game sudah berakhir (oleh timer atau jawaban)
  if (gameState.winner) return { status: 'gameover', newState: gameState };

  const problem = gameState.problems[player];
  const correctAnswer = problem.answer;
  let wasCorrect = false;

  let submittedAnswer;
  if (answerType === 'dragdrop') submittedAnswer = parseFloat(answer);
  else submittedAnswer = parseInt(answer, 10);

  if (Math.abs(submittedAnswer - correctAnswer) < 0.001) {
    wasCorrect = true;
    
    if (player === 'p1') gameState.player1.score++;
    else gameState.player2.score++;
    
    if (player === 'p1') gameState.ropePercent += ROPE_PULL_AMOUNT;
    else gameState.ropePercent -= ROPE_PULL_AMOUNT;
    gameState.ropePercent = Math.max(0, Math.min(100, gameState.ropePercent));

    if (gameState.ropePercent <= WIN_THRESHOLD_P1_LOSES) gameState.winner = 'p2';
    else if (gameState.ropePercent >= WIN_THRESHOLD_P2_LOSES) gameState.winner = 'p1';

    if (!gameState.winner) {
      gameState.difficulty = getDifficultyParams(gameState.gameMode);
      gameState.problems[player] = generateProblemFromParams(gameState.difficulty);
    }
    
    cache.put(roomCode, JSON.stringify(gameState), CACHE_EXPIRATION_SECONDS);
  }

  return { status: 'submitted', wasCorrect: wasCorrect, newState: gameState };
}

// BARU: Fungsi untuk mengakhiri game
function endGameByTime(roomCode, winner) {
  const cache = CacheService.getScriptCache();
  const roomData = cache.get(roomCode);
  if (!roomData) return { status: 'error', message: 'Room not found' };
  
  let gameState = JSON.parse(roomData);
  // Hanya set pemenang jika belum ada
  if (!gameState.winner) {
    gameState.winner = winner; // 'p1', 'p2', or 'draw'
    cache.put(roomCode, JSON.stringify(gameState), CACHE_EXPIRATION_SECONDS);
  }
  return { status: 'ended', newState: gameState };
}


// --- ================================== ---
// --- LOGIKA KESULITAN & SOAL (LENGKAP) ---
// --- ================================== ---

function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function gcd(a, b) { while (b) { [a, b] = [b, a % b]; } return a; }
function lcm(a, b) { return (a * b) / gcd(a, b); }
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

function getDifficultyParams(mode) {
  let op = mode;
  if (mode === 'campuran') {
    const ops = [
      '+', '-', 'x', '÷', 'kpk', 'fpb', 
      'gradien-persamaan', 'gradien-titik',
      'konversi-satuan', 'pola-aritmatika', 'deret-aritmatika'
    ];
    op = ops[rand(0, ops.length - 1)];
  }
  let params = { op: op, type: 'number' };
  if (op === '+' || op === '-') {
    const level = rand(1, 3);
    if (level === 2) { params.minA = 10; params.maxA = 20; params.minB = 1; params.maxB = 9; }
    else if (level === 3) { params.minA = 10; params.maxA = 20; params.minB = 10; params.maxB = 20; }
    else { params.minA = 1; params.maxA = 9; params.minB = 1; params.maxB = 9; }
  } else if (op === 'x') {
    params.minA = 1; params.maxA = 12; params.minB = 1; params.maxB = 12;
  } else if (op === '÷') {
    params.minA = 1; params.maxA = 12; params.minB = 1; params.maxB = 12;
  } else if (op === 'kpk' || op === 'fpb') {
    params.minA = 2; params.maxA = 15; params.minB = 2; params.maxB = 15;
  } else if (op === 'gradien-persamaan') {
    params.type = 'dragdrop';
    params.subType = rand(1, 3);
  } else if (op === 'gradien-titik') {
    params.type = 'dragdrop';
  } else if (op === 'konversi-satuan' || op === 'pola-aritmatika' || op === 'deret-aritmatika') {
    params.type = 'number';
  }
  return params;
}

function getDragDropChoices(answer) {
  let choices = new Set();
  choices.add(answer);
  choices.add(-answer);
  while (choices.size < 4) {
    let distractor;
    if (Math.random() < 0.5) distractor = answer + rand(1, 3);
    else distractor = rand(-5, 5);
    if (distractor === 0 && (answer === 0 || choices.has(0))) continue;
    choices.add(distractor);
  }
  return shuffle(Array.from(choices));
}

function generateProblemFromParams(params) {
  let a = 0, b = 0, c = 0, m = 0, n = 0, answer = 0, question = "", choices = [];
  let opSymbol = params.op;
  switch (params.op) {
    case '+':
      a = rand(params.minA, params.maxA); b = rand(params.minB, params.maxB);
      answer = a + b; question = `${a} + ${b} = ?`;
      break;
    case '-':
      a = rand(params.minA, params.maxA); b = rand(params.minB, params.maxB);
      if (a < b) [a, b] = [b, a];
      answer = a - b; opSymbol = '−'; question = `${a} ${opSymbol} ${b} = ?`;
      break;
    case 'x':
      a = rand(params.minA, params.maxA); b = rand(params.minB, params.maxB);
      answer = a * b; opSymbol = '×'; question = `${a} ${opSymbol} ${b} = ?`;
      break;
    case '÷':
      b = rand(params.minB, params.maxB); answer = rand(params.minA, params.maxA);
      a = b * answer;
      opSymbol = '÷'; question = `${a} ${opSymbol} ${b} = ?`;
      break;
    case 'kpk':
      a = rand(params.minA, params.maxA); b = rand(params.minB, params.maxB);
      answer = lcm(a, b); question = `KPK(${a}, ${b}) = ?`;
      break;
    case 'fpb':
      a = rand(params.minA, params.maxA); b = rand(params.minB, params.maxB);
      answer = gcd(a, b); question = `FPB(${a}, ${b}) = ?`;
      break;
    case 'gradien-persamaan':
      m = rand(-3, 3);
      answer = m;
      switch (params.subType) {
        case 1: // y = mx + c
          c = rand(-10, 10);
          question = `y = ${m === 1 ? '' : m === -1 ? '-' : m}x ${c >= 0 ? '+' : '-'} ${Math.abs(c)}`;
          if (m === 0) question = `y = ${c}`;
          break;
        case 2: // ax + by = c
          b = rand(1, 3); a = -m * b; c = rand(1, 20);
          question = `${a === 1 ? '' : a === -1 ? '-' : a}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)}y = ${c}`;
          break;
        case 3: // ax + by + c = 0
          b = rand(1, 3); a = -m * b; c = rand(-20, 20);
          question = `${a === 1 ? '' : a === -1 ? '-' : a}x ${b >= 0 ? '+' : '-'} ${Math.abs(b)}y ${c >= 0 ? '+' : '-'} ${Math.abs(c)} = 0`;
          break;
      }
      choices = getDragDropChoices(answer);
      break;
    case 'gradien-titik':
      m = rand(-3, 3);
      let x1 = rand(-5, 5); let y1 = rand(-5, 5);
      let x2 = rand(-5, 5);
      while (x1 === x2) x2 = rand(-5, 5);
      let y2 = m * (x2 - x1) + y1;
      answer = m;
      question = `Titik (${x1}, ${y1}) & (${x2}, ${y2})`;
      choices = getDragDropChoices(answer);
      break;
    case 'konversi-satuan':
      const units = [
        ['km', 'm', 1000], ['m', 'cm', 100], ['kg', 'g', 1000], 
        ['l', 'ml', 1000], ['m', 'mm', 1000], ['cm', 'mm', 10]
      ];
      let pair = units[rand(0, units.length - 1)];
      let val = rand(1, 50);
      question = `${val} ${pair[0]} = ? ${pair[1]}`;
      answer = val * pair[2];
      break;
    case 'pola-aritmatika':
      a = rand(1, 20); b = rand(1, 5);
      question = `${a}, ${a + b}, ${a + 2 * b}, ...?`;
      answer = a + 3 * b;
      break;
    case 'deret-aritmatika':
      a = rand(1, 10); b = rand(1, 5);
      n = [4, 6][rand(0, 1)];
      answer = (n / 2) * (2 * a + (n - 1) * b);
      question = `Hitung ${n} suku: ${a}, ${a + b}, ${a + 2 * b}, ...`;
      break;
  }
  return { 
    question: question, 
    answer: answer, 
    type: params.type,
    choices: choices
  };
}

