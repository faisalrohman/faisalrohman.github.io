import os
import pikepdf
import fitz

# ---------------------------------------------------------
# KONFIGURASI PATH UNTUK TERMUX (Memori Internal Android)
# ---------------------------------------------------------
base_path = os.path.dirname(os.path.abspath(__file__))

input_folder = os.path.join(base_path, "folder_awal")
output_folder = os.path.join(base_path, "folder_hasil")

# Ekstensi diupdate menggunakan .jpg untuk Faisal sesuai permintaan
signature_salim_path = os.path.join(base_path, "TTD.png")
signature_faisal_path = os.path.join(base_path, "ttd_faisal.png") 

# Buat kerangka folder jika belum ada di HP
if not os.path.exists(input_folder) or not os.path.exists(output_folder):
    os.makedirs(input_folder, exist_ok=True)
    os.makedirs(output_folder, exist_ok=True)
    print(f"📁 Folder kerja telah dibuat: {base_path}")
    print("⚠️  TINDAKAN DIPERLUKAN:")
    print("1. Pindahkan file .pdf ke dalam folder: folder_awal")
    print("2. Pindahkan gambar TTD.png & ttd_faisal.jpg ke folder yang sama dengan script ini.")
    print("3. Jalankan ulang script ini jika file sudah siap.")
    exit()

# Cek ketersediaan masing-masing file gambar tanda tangan
has_salim = os.path.exists(signature_salim_path)
has_faisal = os.path.exists(signature_faisal_path)

if not has_salim and not has_faisal:
    print("❌ ERROR: Tidak ada satupun file gambar tanda tangan (TTD.png / ttd_faisal.png) yang ditemukan!")
    exit()

if not has_faisal:
    print("⚠️  PERINGATAN: 'ttd_faisal.jpg' tidak ditemukan. Hanya akan memproses tanda tangan SALIM.")
if not has_salim:
    print("⚠️  PERINGATAN: 'TTD.png' tidak ditemukan. Hanya akan memproses tanda tangan FAISAL ROHMAN.")

# Loop semua file PDF di folder input
files_found = [f for f in os.listdir(input_folder) if f.lower().endswith(".pdf")]
if not files_found:
    print(f"ℹ️ Tidak ada file PDF yang ditemukan di folder: folder_awal")
    exit()

print("🚀 Memulai proses penyisipan tanda tangan...\n" + "="*50)

for filename in files_found:
    pdf_path = os.path.join(input_folder, filename)
    temp_clean_path = os.path.join(output_folder, "clean_" + filename)
    output_path = os.path.join(output_folder, filename)

    try:
        # --- TAHAP 1: Membersihkan Dokumen ---
        with pikepdf.open(pdf_path) as pdf:
            if "/AcroForm" in pdf.Root:
                del pdf.Root.AcroForm
            pdf.save(temp_clean_path)
        
        # --- TAHAP 2: Insert Gambar ---
        doc = fitz.open(temp_clean_path)
        
        total_signatures = 0
        pages_with_signatures = set() 

        print(f"\n📄 Memproses: {filename} (Total Awal: {len(doc)} Halaman)")

        for page_num in range(len(doc)):
            page = doc[page_num]
            salim_count_page = 0
            faisal_count_page = 0

            # 1. TANDA TANGAN SALIM
            if has_salim:
                salim_instances = page.search_for("SALIM")
                if salim_instances:
                    for inst in salim_instances:
                        x0, y0, x1, y1 = inst
                        ttd_y0 = max(0, (y0 - 5) - 50)
                        rect = fitz.Rect(max(0, x0 - 50), ttd_y0, min(max(0, x0 - 50) + 200, page.rect.width), min(y0 - 5, page.rect.height))
                        page.insert_image(rect, filename=signature_salim_path)
                        
                        salim_count_page += 1
                        total_signatures += 1
                        pages_with_signatures.add(page_num) 

            # 2. TANDA TANGAN FAISAL ROHMAN
            if has_faisal:
                faisal_instances = page.search_for("FAISAL ROHMAN")
                if faisal_instances:
                    for inst in faisal_instances:
                        x0, y0, x1, y1 = inst
                        
                        # ========================================================
                        # PENGATURAN POSISI TANDA TANGAN FAISAL ROHMAN
                        # ========================================================
                        ttd_width = 200   # Lebar gambar TTD
                        ttd_height = 50   # Tinggi gambar TTD
                        
                        # UBAH ANGKA DI BAWAH INI JIKA POSISI MASIH KURANG PAS:
                        geser_kiri = 60   # Sebelumnya 50. Semakin besar angkanya, semakin geser ke kiri.
                        geser_turun = 7  # Sebelumnya -5 (di atas nama). Nilai positif (+) akan membuat TTD turun mendekati/menimpa nama.
                        # ========================================================

                        ttd_x0 = x0 - geser_kiri
                        ttd_y1 = y0 + geser_turun
                        ttd_y0 = ttd_y1 - ttd_height
                        ttd_x1 = ttd_x0 + ttd_width

                        # Memastikan tanda tangan tidak keluar dari batas ukuran kertas
                        ttd_y0 = max(0, ttd_y0)
                        ttd_x0 = max(0, ttd_x0)
                        ttd_y1 = min(ttd_y1, page.rect.height)
                        ttd_x1 = min(ttd_x1, page.rect.width)

                        rect = fitz.Rect(ttd_x0, ttd_y0, ttd_x1, ttd_y1)
                        page.insert_image(rect, filename=signature_faisal_path)
                        
                        faisal_count_page += 1
                        total_signatures += 1
                        pages_with_signatures.add(page_num) 
            
            if salim_count_page > 0 or faisal_count_page > 0:
                print(f"  └── [v] +TTD di Halaman asli {page_num + 1}")

        # --- TAHAP 3: Menambah Halaman Kosong (Cetak Bolak-Balik) ---
        added_blank_pages = 0
        
        for p_index in sorted(list(pages_with_signatures)):
            current_actual_index = p_index + added_blank_pages
            halaman_asli = current_actual_index + 1 
            
            if halaman_asli % 2 != 0: 
                page_rect = doc[current_actual_index].rect 
                doc.new_page(pno=current_actual_index + 1, width=page_rect.width, height=page_rect.height)
                added_blank_pages += 1
                
                print(f"  └── [📄] TTD di Halaman {halaman_asli} (Ganjil) -> Halaman kosong ditambahkan.")
            else:
                print(f"  └── [⏩] TTD di Halaman {halaman_asli} (Genap) -> Tidak perlu tambah halaman.")

        # --- TAHAP 4: Simpan dan Bersihkan ---
        if total_signatures > 0:
            doc.save(output_path, garbage=3, deflate=True)
            print(f"✅ Selesai: {filename}")
            print(f"   📊 RINGKASAN: {len(pages_with_signatures)} halaman TTD | {added_blank_pages} halaman kosong disisipkan.")
        else:
            print(f"ℹ️ Dilewati: Tidak ada target nama yang ditemukan di {filename}.")
            
        doc.close()

        if os.path.exists(temp_clean_path):
            os.remove(temp_clean_path)

    except Exception as e:
        print(f"❌ Gagal memproses {filename} karena error: {e}")
        if os.path.exists(temp_clean_path):
            os.remove(temp_clean_path)

print("\n" + "="*50)
print("🎉 SEMUA PROSES SELESAI! Cek folder: folder_hasil")