import os
import pikepdf
import fitz

# ---------------------------------------------------------
# KONFIGURASI PATH UNTUK TERMUX (Memori Internal Android)
# ---------------------------------------------------------
# Konstanta path baru (otomatis mendeteksi folder tempat script ini ditaruh)
base_path = os.path.dirname(os.path.abspath(__file__))

input_folder = os.path.join(base_path, "folder_awal")
output_folder = os.path.join(base_path, "folder_hasil")
signature_salim_path = os.path.join(base_path, "TTD.png")
signature_faisal_path = os.path.join(base_path, "ttd_faisal.png")

# Buat kerangka folder jika belum ada di HP
if not os.path.exists(base_path):
    os.makedirs(input_folder, exist_ok=True)
    os.makedirs(output_folder, exist_ok=True)
    print(f"📁 Folder kerja telah dibuat di memori internal: Download/AutoTTD")
    print("⚠️  TINDAKAN DIPERLUKAN:")
    print("1. Buka aplikasi File Manager di HP kamu.")
    print("2. Pindahkan file .pdf ke dalam folder: Download/AutoTTD/folder_awal")
    print("3. Pindahkan gambar ttd_pak_salim...png & ttd_faisal.png ke: Download/AutoTTD/")
    print("4. Jalankan ulang script ini jika file sudah siap.")
    exit()

# Cek apakah gambar tanda tangan ada
if not os.path.exists(signature_salim_path) or not os.path.exists(signature_faisal_path):
    print("❌ ERROR: File gambar tanda tangan tidak ditemukan di folder Download/AutoTTD/")
    exit()

# Loop semua file PDF di folder input
files_found = [f for f in os.listdir(input_folder) if f.lower().endswith(".pdf")]
if not files_found:
    print(f"ℹ️ Tidak ada file PDF yang ditemukan di {input_folder}")
    exit()

print("🚀 Memulai proses penyisipan tanda tangan...\n" + "="*50)

for filename in files_found:
    pdf_path = os.path.join(input_folder, filename)
    temp_clean_path = os.path.join(output_folder, "clean_" + filename)
    output_path = os.path.join(output_folder, filename)

    try:
        # --- TAHAP 1: Membersihkan Dokumen ---
        with pikepdf.open(pdf_path) as pdf:
            if "/AcroForm" in pdf.Root:
                del pdf.Root.AcroForm
            pdf.save(temp_clean_path)
        
        # --- TAHAP 2: Insert Gambar ---
        doc = fitz.open(temp_clean_path)
        
        # Variabel pelacak statistik
        total_signatures = 0
        pages_with_signatures = set() # Menggunakan set agar nomor halaman tidak ganda

        print(f"\n📄 Memproses: {filename} (Total: {len(doc)} Halaman)")

        for page_num in range(len(doc)):
            page = doc[page_num]
            salim_count_page = 0
            faisal_count_page = 0

            # 1. TANDA TANGAN SALIM
            salim_instances = page.search_for("SALIM")
            if salim_instances:
                for inst in salim_instances:
                    x0, y0, x1, y1 = inst
                    ttd_y0 = max(0, (y0 - 5) - 50)
                    rect = fitz.Rect(max(0, x0 - 50), ttd_y0, min(max(0, x0 - 50) + 200, page.rect.width), min(y0 - 5, page.rect.height))
                    page.insert_image(rect, filename=signature_salim_path)
                    
                    salim_count_page += 1
                    total_signatures += 1
                    pages_with_signatures.add(page_num + 1)

            # 2. TANDA TANGAN FAISAL ROHMAN
            faisal_instances = page.search_for("FAISAL ROHMAN")
            if faisal_instances:
                for inst in faisal_instances:
                    x0, y0, x1, y1 = inst
                    ttd_y0 = max(0, (y0 - 5) - 50)
                    rect = fitz.Rect(max(0, x0 - 50), ttd_y0, min(max(0, x0 - 50) + 200, page.rect.width), min(y0 - 5, page.rect.height))
                    page.insert_image(rect, filename=signature_faisal_path)
                    
                    faisal_count_page += 1
                    total_signatures += 1
                    pages_with_signatures.add(page_num + 1)
            
            # Print rincian per halaman jika ada perubahan
            if salim_count_page > 0 or faisal_count_page > 0:
                print(f"  └── [v] Halaman {page_num + 1}: +{salim_count_page} ttd Salim, +{faisal_count_page} ttd Faisal")

        # --- TAHAP 3: Simpan dan Bersihkan ---
        if total_signatures > 0:
            doc.save(output_path, garbage=3, deflate=True)
            print(f"✅ Selesai: {filename}")
            print(f"   📊 RINGKASAN: {len(pages_with_signatures)} halaman dimodifikasi | {total_signatures} total ttd disisipkan.")
        else:
            print(f"ℹ️ Dilewati: Tidak ada target nama yang ditemukan di {filename}.")
            
        doc.close()

        # Hapus file bersih sementara
        if os.path.exists(temp_clean_path):
            os.remove(temp_clean_path)

    except Exception as e:
        print(f"❌ Gagal memproses {filename} karena error: {e}")
        if os.path.exists(temp_clean_path):
            os.remove(temp_clean_path)

print("\n" + "="*50)
print("🎉 SEMUA PROSES SELESAI! Cek folder Download/AutoTTD/folder_hasil")