# OTP Manager

Ekstensi Browser untuk menghasilkan kode OTP secara langsung

## Pengguna khusus

Ekstensi ini bisa dipakai untuk menghasilkan berbagai kode OTP, namun ada fitur khusus yakni kode OTP akan otomatis terisi ke form input diantaranya issuer Dapodik, SDM, dll.

Jika akan menggunakan fitur pengguna khusus tersebut, kita harus setting issuer terlebih dahulu. Jika bukan default, Gunakan tombol edit untuk mengubahnya.

#### Issuer yang tersedia

* Dapodik
* SDM
* SIASN
* InfoGTK

Pastikan besar kecilnya sama, selain dari itu menggunakan [ctrl] + [v]
